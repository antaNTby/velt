<?php

header('Location: app');
