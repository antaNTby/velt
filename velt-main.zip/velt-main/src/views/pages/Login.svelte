<form method="post">
  <h2>Login</h2>
  <input type="email" name="email" value="example@mail.com" />
  <input type="password" name="password" value="12345678" />
  <button>Login</button>
</form>
