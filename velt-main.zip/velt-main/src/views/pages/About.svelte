<script>
  export let flightVersion = "";
  export let svelteVersion = "";
</script>

<p>
  Powered by
  <a href="https://docs.flightphp.com">Flight {flightVersion}</a>
  +
  <a href="https://svelte.dev">Svelte {svelteVersion}</a>
</p>
